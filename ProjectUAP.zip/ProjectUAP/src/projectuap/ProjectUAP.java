package projectuap;
import db.DBHelper;

public class ProjectUAP {

    public static void main(String[] args) {
        Barang brg = new Barang("jaya111", "2022-10", "shampoo", 30000, 300, 1000, "alat mandi");
        BarangModel bm = new BarangModel();
        bm.addBarang(brg);
    }
    
}
